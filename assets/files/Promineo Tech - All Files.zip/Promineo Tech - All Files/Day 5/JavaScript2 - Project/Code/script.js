// JS FIDDLE LINK: https://jsfiddle.net/cassthecoder/3gL0djk1/

window.onload = () => {
    let button = document.getElementById("genID");
    button.addEventListener("click", createId);
};

function createId(){
    //  get first and last name to combine to make full name
    let firstName = document.getElementById("first").value;
    let lastName = document.getElementById("last").value;
    let fullName = firstName + " " + lastName;

    // birthday in format "MM/DD/YYYY"
    // assume user will enter information in correct format
    let birthday = document.getElementById("bday").value
    let age = calculateAge(birthday);

    // get user's study focus
    let studyFocus = document.getElementById("focus").value;

    // get grades for all courses
    let numGrade1 = parseInt(document.getElementById("grade1").value);
    let numGrade2 = parseInt(document.getElementById("grade2").value);
    let numGrade3 = parseInt(document.getElementById("grade3").value);
    let numGrade4 = parseInt(document.getElementById("grade4").value);

    // put all grades in an array
    let gradeArray = [numGrade1, numGrade2, numGrade3, numGrade4];
    
    // call average() function to calculate numeric average
    let numAvg = average(gradeArray);

    // call convertNumToLetter() function to convert numeric average to letter average
    let letterAvg = convertNumToLetter(numAvg);

    // display all gathered information in id card for user to see
    document.getElementById("fullName").innerHTML = fullName;
    document.getElementById("age").innerHTML = age;
    document.getElementById("studyFocus").innerHTML = studyFocus;
    document.getElementById("avg").innerHTML = letterAvg;

    // change visibility property of idCard from hidden to visible
    document.getElementById("idCard").style.visibility = "visible";
}

function calculateAge(birthdayString){
    let today = new Date();
    // need to change "MM/DD/YYYY" to "MM DD YYYY"
    birthdayString.replace("/"," ");
    let birthDate = new Date(birthdayString);
    // get difference in years
    let age = today.getFullYear() - birthDate.getFullYear();
    // get difference to compare months
    let m = today.getMonth() - birthDate.getMonth();
    // if month has not passed or if the same month and date has not passed
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) 
    {
        //decrease age by 1 year
        age--;
    }
    return age;
}

function average(grades){
    //assume that grades is not an empty array

    //create variables to hold our average and sum
    let avg = 0
    let sum = 0;

    //loop through array to calculate sum
    for(let i = 0; i < grades.length; i++){
        sum += grades[i];
    }

    //calculate average = sum / total number of grades
    avg = sum / grades.length;
    return avg;
}

function convertNumToLetter(number){
    let letterGrade;
    // compare inputted number to different grade ranges and assign appropriate letter grade
    if(number >= 90){
        letterGrade = "A";
    }
    else if(number >= 80){
        letterGrade = "B";
    }
    else if(number >= 70){
        letterGrade = "C";
    }
    else if(number >= 60){
        letterGrade = "D";
    }
    else{
        letterGrade = "F";
    }
    return letterGrade;
}