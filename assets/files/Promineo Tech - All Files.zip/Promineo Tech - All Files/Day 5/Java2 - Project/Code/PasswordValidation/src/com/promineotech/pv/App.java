package com.promineotech.pv;

import java.util.Scanner;

public class App {
	public static final int PASSWORD_LENGTH = 9;

	public static void main(String[] args) {
//		Password rules:
//			A password must have at least nine characters.
//			A password must contain at least two digits.
//			A password must contain at least three letters.
//			A password must contain one of these special characters: !@#$%
	
//		Create new instance of scanner to get user input
        Scanner scan = new Scanner(System.in);
        
//      Display password rules
        System.out.print(
                "1. A password must have at least nine characters.\n" +
                "2. A password must contain at least two digits.\n" +
                "3. A password must contain at least three letters.\n" +
                "4. A password must contain one of these special characters: !@#$% \n" +
                "Enter a password: ");
        
//      Get user's inputed password
        String pw = scan.nextLine();
        
//		Check to see if password is valid by calling method
       isValidPassword(pw);

	}

//	Method to check if password is valid - returns boolean	
    public static void isValidPassword(String password) {
    	
        if(password.length() < PASSWORD_LENGTH){
        	System.out.println("Your password does not meet the length requirements.");
        }

        int letterCount = 0;
        int numCount = 0;
        int specialCount = 0;
        int invalidCount = 0;
        for(int i = 0; i < password.length(); i++){

            char ch = password.charAt(i);

            if(isNumeric(ch)) {
            	numCount++;
            }
            else if(isLetter(ch)) {
            	letterCount++;
            }
            else if(isSpecial(ch)){
            	specialCount++;
            }
            else {
            	invalidCount++; 
            }
        }

        if(invalidCount == password.length()) {
        	System.out.println("Your password contains all invalid characters.");
        }
        else if(letterCount >= 3 && numCount >= 2 && specialCount >= 1) {
        	System.out.println("Password is valid: " + password);
        }
        else {
        	System.out.println("Your password has an invalid amount of letters, digits, or special characters.");
        }
        
    }

//    Method to check if inputed character is a letter
    public static boolean isLetter(char ch){
        ch = Character.toUpperCase(ch);
        return (ch >= 'A' && ch <= 'Z');
    }

//  Method to check if inputed character is a digit
    public static boolean isNumeric(char ch) {

        return (ch >= '0' && ch <= '9');
    }

//  Method to check if inputed character is a specified special character
    public static boolean isSpecial(char ch) {
    	return (ch == '!' || ch == '@' || ch == '#' || ch == '$' || ch == '%'); 

    }
	

}


