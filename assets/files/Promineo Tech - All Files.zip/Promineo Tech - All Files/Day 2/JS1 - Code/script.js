// JS FIDDLE LINK: https://jsfiddle.net/cassthecoder/dy6auo8q/

// wait for DOM to finish loading
window.onload = () => {

    // create a variable to be the calculation button
    let submit = document.getElementById("btn-result");

    // add event listener to calculation button and wait for click
    submit.addEventListener("click", function(){

        // grab all user inputs
        let bill = parseFloat(document.getElementById("bill").value);
        let tip = parseFloat(document.getElementById("tip-input").value);
        let nop = parseInt(document.getElementById("nop").value);

        // calculate total tip
        let tipAmount = (bill * (tip/100));
        // calculate total tip per person
        let tipPp = tipAmount/nop;
        // calculate total bill including tip per person
        let totalBillPp = (bill + tipAmount)/nop;

        // insert calculated values back to the DOM for user to view
        document.getElementById("tip-amount").innerHTML = tipPp.toFixed(2);
        document.getElementById("bill-amount").innerHTML = totalBillPp.toFixed(2);

    });

}