package com.promineotech.zodiac;

public class App {
	
	//Tutorials point link: http://tpcg.io/LBrPpd1b

	//Zodiac Signs:
	// Dec 22 - Jan 19 Capricorn
    // Jan 20 - Feb 18 Aquarius
    // Feb 19 - March 20 Pisces 
    // March 21 - April 19 Aries 
    // April 20 - May 20 Taurus
    // May 21 - June 20 Gemini
    // June 21 - July 22 Cancer 
    // July 23 - Aug 22 Leo 
    // Aug 23 - Sept 22 Virgo
    // Sept 23 - Oct 22 Libra 
    // Oct 23 - Nov 21 Scorpio 
    // Nov 22 - Dec 21 Sagittarius
	
	
	public static void main(String[] args) {
		//change the below variables to test switch case to calculate zodiac sign
		String month = "";
        int date = 0;
        //this variable is to hold the calculated sign
        String zodiac = "";
        
        //switch case to first examine month given
        switch(month.toLowerCase()){
            case "january":
                //check dates
                if(date <= 19){
                   zodiac = "Capricorn";
                }
                else{
                    zodiac = "Aquarius";
                }
                break;
            case "february":
                //check dates
                if(date <= 18){
                    zodiac = "Aquarius";
                }
                else{
                    zodiac = "Pisces";
                }
                break;
            case "march":
                //check dates
                if(date <= 20){
                    zodiac = "Pisces";
                }
                else{
                    zodiac = "Aries";
                }
                break;
            case "april":
                //check dates
                if(date <= 19){
                    zodiac = "Aries";
                }
                else{
                    zodiac = "Taurus";
                }
                break;
            case "may":
                //check dates
                if(date <= 20){
                    zodiac = "Taurus";
                }
                else{
                    zodiac = "Gemini";
                }
                break;
            case "june":
                //check dates
                if(date <= 20){
                    zodiac = "Gemini";
                }
                else{
                    zodiac = "Cancer";
                }
                break;
            case "july":
                //check dates
                if(date <= 22){
                    zodiac = "Cancer";
                }
                else{
                    zodiac = "Leo";
                }
                break;
            case "august":
                //check dates
                if(date <= 22){
                    zodiac = "Leo";
                }
                else{
                    zodiac = "Virgo";
                }
                break;
            case "september":
                //check dates
                if(date <= 22){
                    zodiac = "Virgo";
                }
                else{
                    zodiac = "Libra";
                }
                break;
            case "october":
                //check dates
                if(date <= 22){
                    zodiac = "Libra";
                }
                else{
                    zodiac = "Scorpio";
                }
                break;
            case "november":
                //check dates
                if(date <= 21){
                    zodiac = "Scorpio";
                }
                else{
                    zodiac = "Sagittarius";
                }
                break;
            case "december":
                //check dates
                if(date <= 21){
                    zodiac = "Sagittarius";
                }
                else{
                    zodiac = "Capricorn";
                }
                break;
            default:
                System.out.println("Invalid month was given, cannot calculate Zodiac");
        }
        
        //write to the console the calculated sign
        System.out.println("Zodiac Sign: " + zodiac);
	}

}
