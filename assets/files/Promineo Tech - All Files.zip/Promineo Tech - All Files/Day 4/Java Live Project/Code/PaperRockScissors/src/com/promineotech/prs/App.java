package com.promineotech.prs;

import java.util.Scanner;

public class App {

	public static void main(String[] args) {
		// Prompt the user
		System.out.println("Let's play Paper, Rock, Scissors");
		// Create new instance of scanner to get user input
		Scanner input = new Scanner(System.in);
		// Prompt each player and get their move
		System.out.println("Player One, make a move:");
		String playerOne = input.next();
		System.out.println("Player Two, make your move:");
		String playerTwo = input.next();
		// Send each player's moves to the whoWins() method to see which player wins
		whoWins(playerOne, playerTwo);

	}
	
	public static void whoWins(String p1, String p2) {
		// Check to see if both inputs are the same for a potential tie
		if(p1.equals(p2)) {
			 System.out.println("It's a tie!");
		}
		else {
			// Use a switch case based off player one's move to see which player one
			switch(p1) {
			case "rock":
				// Based of the case, compare to the two other possible options
				if(p2.equals("scissors")) {
					System.out.print("Player One wins");
				}
				else if(p2.equals("paper")) {
					System.out.print("Player Two wins");
				}
				break;
			case "paper":
				if(p2.equals("rock")) {
					System.out.print("Player One wins");
				}
				else if(p2.equals("scissors")) {
					System.out.print("Player Two wins");
				}
				break;
			case "scissors":
				if(p2.equals("rock")) {
					System.out.print("Player One wins");
				}
				else if(p2.equals("paper")) {
					System.out.print("Player Two wins");
				}
				break;
			}
		}

	}
}