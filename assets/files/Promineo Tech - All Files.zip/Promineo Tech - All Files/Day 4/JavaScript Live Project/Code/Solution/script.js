// JS FIDDLE LINK: https://jsfiddle.net/cassthecoder/oztuwaqd/
//Simple Word Counter
//Assumptions: 
    // There are no leading/trailing spaces
    // All entered text are valid words

    window.onload = () => {

        // create a variable to be the word count button
        let wordCountBtn = document.getElementById("count-btn");
        
        // add event listener to calculation button and wait for click
        wordCountBtn.addEventListener("click", function(){
            // create variables to hold values for totals
            let totalSpaces = 0;
            let totalWords = 0;
    
            // grab user's inputted text
            let text = document.getElementById("input-text").value;
    
            // loop through text and look at each character
            for(let i = 0; i < text.length; i++){
                // update space count if current character is a space
                if(text.charAt(i) == ' '){
                    ++totalSpaces;
                }
            }
    
            // calculate total words based of total spaces
            totalWords = totalSpaces + 1;
    
            // insert calculated values back to the DOM for user to view
            document.getElementById("result").innerHTML = "Total Words: " + totalWords;
        });
    };