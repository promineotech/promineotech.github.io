// JS FIDDLE LINK: https://jsfiddle.net/cassthecoder/xnw7ve92/
//Simple Word Counter
//Assumptions: 
    // There are no leading/trailing spaces
    // All entered text are valid words